package com.chargefinder.registration;

import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chargefinder.bean.User;
import com.chargefinder.dao.ApplicationDao;




@WebServlet("/account")
public class EditAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = null;
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String phoneNumber = request.getParameter("contact");
		String userType = request.getParameter("type");
		UUID userId = UUID.fromString(request.getParameter("userId"));
		HttpSession session = request.getSession();
		
		user = new User.UserBuilder(username)
				.userId(userId)
				.email(email)
				.password(password)
				.phoneNumber(phoneNumber)
				.userType(userType)
				.build();
				
				
		RequestDispatcher dispatcher = null;
		ApplicationDao dao = new ApplicationDao();
	
		try {
			dao.updateUser(user);
			dispatcher = request.getRequestDispatcher("account.jsp");
			
			if (dao.getRowCount() > 0) {
				request.setAttribute("status", "success");
			}else {
				request.setAttribute("status", "failed");
			}
			
			if (dao.getRS().next()) {
				session.setAttribute("userId", dao.getRS().getString("userId"));
				session.setAttribute("username", dao.getRS().getString("username"));
				session.setAttribute("email", dao.getRS().getString("email"));
				session.setAttribute("password", dao.getRS().getString("password"));
				session.setAttribute("phoneNumber", dao.getRS().getString("phoneNumber"));
				session.setAttribute("userType", dao.getRS().getString("userType"));
				
			}else {
				request.setAttribute("status", "failed");
			}
			dispatcher.forward(request, response);
			}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dao.getConn().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		request.changeSessionId();
		}
	

	}
