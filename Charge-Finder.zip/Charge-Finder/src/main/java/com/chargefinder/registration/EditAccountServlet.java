package com.chargefinder.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




@WebServlet("/account")
public class EditAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String phoneNumber = request.getParameter("contact");
		String userType = request.getParameter("type");
		HttpSession session = request.getSession();
		Object sqlId = session.getAttribute("id");
		RequestDispatcher dispatcher = null;
		Connection con = null;
	
		/* Update account information */
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ChargeFinder?useSSL=false", "root", "sql");

			PreparedStatement post = con.prepareStatement("update users set username = ?, email = ?, password = ?, phoneNumber = ?, userType= ? where id = ?;");
			post.setString(1, username);
			post.setString(2, email);
			post.setString(3, password);
			post.setString(4, phoneNumber);
			post.setString(5, userType);
			post.setObject(6, sqlId);
			
			int rowCount = post.executeUpdate();
			dispatcher = request.getRequestDispatcher("account.jsp");
			
			if (rowCount > 0) {
				request.setAttribute("status", "success");
			}else {
				request.setAttribute("status", "failed");
			}
			
			/* Update the session attribute after update */
			PreparedStatement post2 = con.prepareStatement("select * from users where id = ?");
			post2.setObject(1,sqlId);
			
			ResultSet rs = post2.executeQuery();
			if (rs.next()) {
				session.setAttribute("id", rs.getInt("id"));
				session.setAttribute("username", rs.getString("username"));
				session.setAttribute("email", rs.getString("email"));
				session.setAttribute("password", rs.getString("password"));
				session.setAttribute("phoneNumber", rs.getString("phoneNumber"));
				session.setAttribute("userType", rs.getString("userType"));
				
			}else {
				request.setAttribute("status", "failed");
		} 
			dispatcher.forward(request, response);
			}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		request.changeSessionId();
		}
	

	}
