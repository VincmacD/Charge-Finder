package com.chargefinder.registration;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chargefinder.bean.ChargingStation;
import com.chargefinder.bean.ChargingStation.StationBuilder;
import com.chargefinder.dao.ApplicationDao;


@WebServlet("/addStation")
public class AddStationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		String stationName = request.getParameter("stationName");
		String stationAddress = request.getParameter("stationAddress");
		float lat = Float.parseFloat(request.getParameter("lat"));
		float lng = Float.parseFloat(request.getParameter("lng"));
		String stationStatus = request.getParameter("stationStatus");
		String stationOutput = request.getParameter("stationOutput");
		String stationCost = request.getParameter("stationCost");
		int numStations = Integer.parseInt(request.getParameter("numStations").toString());
		int stationAvailability = Integer.parseInt(request.getParameter("stationAvailability").toString());
		String stationSchedule = request.getParameter("stationSchedule");
		String navigateLink = request.getParameter("navigateLink");
		String stationCity = request.getParameter("stationCity");
		
		ChargingStation station = new ChargingStation.StationBuilder(stationName)
				.stationAddress(stationAddress)
				.lat(lat)
				.lng(lng)
				.stationStatus(stationStatus)
				.stationOutput(stationOutput)
				.stationCost(stationCost)
				.numStations(numStations)
				.stationAvailability(stationAvailability)
				.stationSchedule(stationSchedule)
				.stationCity(stationCity)
				.navigateLink(navigateLink)
				.build();
		
		RequestDispatcher dispatcher = null;
		ApplicationDao dao = new ApplicationDao();
		dao.addStation(station);
		dispatcher = request.getRequestDispatcher("add-station.jsp");
		
		if (dao.getRowCount() > 0) {
			request.setAttribute("status", "success");
		}else {
			request.setAttribute("status", "failed");
		}
		dispatcher.forward(request, response);
		
		try {
			dao.getConn().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
}
