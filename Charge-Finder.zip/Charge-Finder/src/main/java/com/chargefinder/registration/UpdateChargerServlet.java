package com.chargefinder.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chargefinder.bean.ChargingStation;
import com.chargefinder.dao.ApplicationDao;

@WebServlet("/UpdateChargerServlet")
public class UpdateChargerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ApplicationDao dao = new ApplicationDao();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UUID stationId = UUID.fromString(request.getParameter("stationId").toString());
		String stationName = request.getParameter("stationName");
		String stationAddress = request.getParameter("stationAddress");
		float lat = Float.parseFloat(request.getParameter("lat"));
		float lng = Float.parseFloat(request.getParameter("lng"));
		String stationStatus = request.getParameter("stationStatus");
		String stationOutput = request.getParameter("stationOutput");
		String stationCost = request.getParameter("stationCost");
		int numStations = Integer.parseInt(request.getParameter("numStations").toString());
		int stationAvailability = Integer.parseInt(request.getParameter("stationAvailability").toString());
		String stationSchedule = request.getParameter("stationSchedule");
		String navigateLink = request.getParameter("navigateLink");
		String stationCity = request.getParameter("stationCity");
		HttpSession session = request.getSession();
		
		ChargingStation station = new ChargingStation.StationBuilder(stationName)
				.stationId(stationId)
				.stationAddress(stationAddress)
				.lat(lat)
				.lng(lng)
				.stationStatus(stationStatus)
				.stationOutput(stationOutput)
				.stationCost(stationCost)
				.numStations(numStations)
				.stationAvailability(stationAvailability)
				.stationSchedule(stationSchedule)
				.stationCity(stationCity)
				.navigateLink(navigateLink)
				.build();
		RequestDispatcher dispatcher = null;
		ApplicationDao dao = new ApplicationDao();
		
		try {
			dao.updateStation(station);
			dispatcher = request.getRequestDispatcher("edit-station.jsp");
			if (dao.getRowCount() > 0) {
				request.setAttribute("status", "success");
			}else {
				request.setAttribute("status", "failed");
			}
			if(dao.getRS().next()) {
				session.setAttribute("stationId", dao.getRS().getString("stationId"));
				session.setAttribute("stationName", dao.getRS().getString("stationName"));
				session.setAttribute("stationAddress", dao.getRS().getString("stationAddress"));
				session.setAttribute("lat", dao.getRS().getFloat("lat"));
				session.setAttribute("lng", dao.getRS().getFloat("lng"));
				session.setAttribute("stationStatus", dao.getRS().getString("stationStatus"));
				session.setAttribute("stationOutput", dao.getRS().getString("stationOutput"));
				session.setAttribute("stationCost", dao.getRS().getString("stationCost"));
				session.setAttribute("numStations", dao.getRS().getInt("numStations"));
				session.setAttribute("stationAvailability", dao.getRS().getInt("stationAvailability"));
				session.setAttribute("stationSchedule", dao.getRS().getString("stationSchedule"));
				session.setAttribute("stationCity", dao.getRS().getString("stationCity"));
				session.setAttribute("navigateLink", dao.getRS().getString("navigateLink"));
			}
			dispatcher.forward(request, response);
			dao.getConn().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		request.changeSessionId();
	}

}
