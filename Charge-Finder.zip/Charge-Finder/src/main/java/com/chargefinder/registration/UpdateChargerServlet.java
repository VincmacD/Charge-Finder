package com.chargefinder.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chargefinder.dao.ApplicationDao;

@WebServlet("/UpdateChargerServlet")
public class UpdateChargerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ApplicationDao dao = new ApplicationDao();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		dao.updateStation(request.getParameter("name").toString(), request.getParameter("address").toString(), request.getParameter("lat").toString(), request.getParameter("lng").toString(), request.getParameter("status").toString(), request.getParameter("output").toString(), request.getParameter("cost").toString(), request.getParameter("numStations").toString(), request.getParameter("availability").toString(), request.getParameter("schedule").toString());
		try {
			dao.getConn().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"ISO-8859-1\">");
		out.println("<title>Update successful!</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h3>Update successful!</h3>");
		out.println("<a href=\"home.jsp\">Return to home</a>");
		out.println("</body>");
		out.println("</html>");
				
	}

}
