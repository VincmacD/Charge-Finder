package com.chargefinder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ApplicationDao {

    private Connection conn = null;
    private PreparedStatement post = null;
    private PreparedStatement post2 = null;
    private int rowCount;
    private ResultSet rs = null;

    public void registerUser(String username, String email, String password, String phoneNumber, String userType) {
    	
    	try {
    		conn = DBConnection.getConnection();
    		post = conn.prepareStatement("insert into users(username,email,password,phoneNumber,userType) values(?,?,?,?,?) ");
			post.setString(1, username);
			post.setString(2, email);
			post.setString(3, password);
			post.setString(4, phoneNumber);
			post.setString(5, userType);
			
			rowCount = post.executeUpdate();
    		
    		
    	} catch(Exception e) {
    		e.printStackTrace();
    	}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}	
    }
    
    public void logIn(String username, String password) {
    	
		try {
			conn = DBConnection.getConnection();
			PreparedStatement post = conn.prepareStatement("select * from users where username = ? and password = ?");
			post.setString(1, username);
			post.setString(2, password);
			
			rs = post.executeQuery();
			
			
		}catch (Exception e) {
			e.printStackTrace();			
		}    	
    }
    
    public void edit(String username, String email, String password, String phoneNumber, String userType, Object sqlId) {
    	
    	try {
    		conn = DBConnection.getConnection();
			PreparedStatement post = conn.prepareStatement("update users set username = ?, email = ?, password = ?, phoneNumber = ?, userType= ? where id = ?;");
			post.setString(1, username);
			post.setString(2, email);
			post.setString(3, password);
			post.setString(4, phoneNumber);
			post.setString(5, userType);
			post.setObject(6, sqlId);
			
			rowCount = post.executeUpdate();
			
			post2 = conn.prepareStatement("select * from users where id = ?");
			post2.setObject(1,sqlId);
			
			rs = post2.executeQuery();
    	}catch (Exception e) {
			e.printStackTrace();
    	}/*finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}*/
    	
    }

	public int getRowCount() {
		return rowCount;
	}

	public ResultSet getRS() {
		return rs;
	}
    
	public Connection getConn() {
		return conn;
	}
	
}
