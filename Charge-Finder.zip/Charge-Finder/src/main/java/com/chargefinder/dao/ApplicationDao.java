package com.chargefinder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ApplicationDao {

    private Connection conn = null;
    private PreparedStatement post = null;
    private PreparedStatement post2 = null;
    private int rowCount;
    private ResultSet rs = null;
    private String city = "Ottawa";
    private Statement stationsSelect = null;

    public void registerUser(String username, String email, String password, String phoneNumber, String userType) {
    	
    	try {
    		conn = DBConnection.getConnection();
    		post = conn.prepareStatement("insert into users(username,email,password,phoneNumber,userType) values(?,?,?,?,?) ");
			post.setString(1, username);
			post.setString(2, email);
			post.setString(3, password);
			post.setString(4, phoneNumber);
			post.setString(5, userType);
			
			rowCount = post.executeUpdate();
    		
    		
    	} catch(Exception e) {
    		e.printStackTrace();
    	}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}	
    }
    
    public void logIn(String username, String password) {
    	
		try {
			conn = DBConnection.getConnection();
			PreparedStatement post = conn.prepareStatement("select * from users where username = ? and password = ?");
			post.setString(1, username);
			post.setString(2, password);
			
			rs = post.executeQuery();
			
			
		}catch (Exception e) {
			e.printStackTrace();			
		}    	
    }
    
    public void edit(String username, String email, String password, String phoneNumber, String userType, Object sqlId) {
    	
    	try {
    		conn = DBConnection.getConnection();
			PreparedStatement post = conn.prepareStatement("update users set username = ?, email = ?, password = ?, phoneNumber = ?, userType= ? where id = ?;");
			post.setString(1, username);
			post.setString(2, email);
			post.setString(3, password);
			post.setString(4, phoneNumber);
			post.setString(5, userType);
			post.setObject(6, sqlId);
			
			rowCount = post.executeUpdate();
			
			post2 = conn.prepareStatement("select * from users where id = ?");
			post2.setObject(1,sqlId);
			
			rs = post2.executeQuery();
    	}catch (Exception e) {
			e.printStackTrace();
    	}
    	
    }
    
    public void getStations() {
    	
    	try {
    		conn = DBConnection.getConnection();
			stationsSelect = conn.createStatement();
			
			rs = stationsSelect.executeQuery("select * from stations where city = '" + city + "'");
    	}catch (Exception e) {
			e.printStackTrace();
    	}
    	
    }
    
    public void editStation(String chargerName) {
    	
    	try {
    		conn = DBConnection.getConnection();
			stationsSelect = conn.createStatement();
			
			rs = stationsSelect.executeQuery("select chargerName, address, lat, lng, status, output, cost, numStations, availability, schedule from stations where chargerName = '" + chargerName + "'");
    	}catch (Exception e) {
			e.printStackTrace();
    	}
    	
    }
    
    public void updateStation(String chargerName,  String address, String lat, String lng, String status, String output, String cost, String numStations, String availability, String schedule){
		conn = DBConnection.getConnection();
		PreparedStatement post;
		try {
			post = conn.prepareStatement("update stations set address = ?, lat = ?, lng = ?, status = ?, output = ?, cost = ?, numStations = ?, availability = ?, schedule = ? where chargerName = ?;");
			post.setString(1, address);
			post.setFloat(2, Float.parseFloat(lat));
			post.setFloat(3, Float.parseFloat(lng));
			post.setString(4, status);
			post.setString(5, output);
			post.setString(6, cost);
			post.setInt(7, Integer.parseInt(numStations));
			post.setBoolean(8, Boolean.parseBoolean(availability));
			post.setString(9, schedule);
			post.setString(10, chargerName);
			
			rowCount = post.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

	public int getRowCount() {
		return rowCount;
	}

	public ResultSet getRS() {
		return rs;
	}
    
	public Connection getConn() {
		return conn;
	}
	
}
