package com.chargefinder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import com.chargefinder.bean.ChargingStation;
import com.chargefinder.bean.User;
import com.mysql.cj.jdbc.result.ResultSetMetaData;

public class ApplicationDao extends HttpServlet {

    private Connection conn = null;
    private PreparedStatement post = null;
    private PreparedStatement post2 = null;
    private int rowCount;
    private ResultSet rs = null;
    private Statement stationsSelect = null;
    


    public void registerUser(User user) {
  
    	try {
    		conn = DBConnection.getConnection();
    		post = conn.prepareStatement("insert into users(userId, username, email, password, phoneNumber, userType) values(?,?,?,?,?,?) ");
			post.setString(1, user.getUserId().toString());
    		post.setString(2, user.getUsername());
			post.setString(3, user.getEmail());
			post.setString(4, user.getPassword());
			post.setString(5, user.getPhoneNumber());
			post.setString(6, user.getUserType());
			
			rowCount = post.executeUpdate();
    		
    		
    	} catch(Exception e) {
    		e.printStackTrace();
    	}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}	
    }
    
    public void logIn(String username, String password) {
    	
		try {
			conn = DBConnection.getConnection();
			PreparedStatement post = conn.prepareStatement("select * from users where username = ? and password = ?");
			post.setString(1, username);
			post.setString(2, password);
			
			rs = post.executeQuery();
		
			
		}catch (Exception e) {
			e.printStackTrace();			
		}    	
    }
    
    public void updateUser(User user) {

    	try {
    		conn = DBConnection.getConnection();
			PreparedStatement post = conn.prepareStatement("update users set username = ?, email = ?, password = ?, phoneNumber = ?, userType= ? where userId = ?;");
			post.setString(1, user.getUsername());
			post.setString(2, user.getEmail());
			post.setString(3, user.getPassword());
			post.setString(4, user.getPhoneNumber());
			post.setString(5, user.getUserType());
			post.setString(6, user.getUserId().toString());
			
			rowCount = post.executeUpdate();
			
			post2 = conn.prepareStatement("select * from users where userId = ?");
			System.out.println(post2);
			post2.setObject(1,user.getUserId().toString());
			
			rs = post2.executeQuery();
    	}catch (Exception e) {
			e.printStackTrace();
    	}
    	
    }
    
    public void getStations() {
    	
    	try {
    		conn = DBConnection.getConnection();
			stationsSelect = conn.createStatement();
			
			rs = stationsSelect.executeQuery("select * from station");
    	}catch (Exception e) {
			e.printStackTrace();
    	}
    	
    }
    
    public void editStation(String stationId) {
    	
    	try {
    		conn = DBConnection.getConnection();
			stationsSelect = conn.createStatement();
			
			rs = stationsSelect.executeQuery("select * from station where stationName = '" + stationId + "'");
    	}catch (Exception e) {
			e.printStackTrace();
    	}
    }
    public void addStation(ChargingStation station) {
      	try {
    		conn = DBConnection.getConnection();
    		post = conn.prepareStatement("insert into station(stationId, stationName, stationAddress, lat, lng, stationStatus, stationOutput, stationCost, numStations, stationAvailability, stationSchedule, navigateLink, stationCity) values(?,?,?,?,?,?,?,?,?,?,?,?,?) ");
			post.setString(1, station.getStationId().toString());
    		post.setString(2, station.getStationName());
    		post.setString(3, station.getStationAddress());
    		post.setFloat(4, station.getLat());
    		post.setFloat(5, station.getLng());
    		post.setString(6,station.getStationStatus());
    		post.setString(7, station.getStationOutput());
    		post.setString(8, station.getStationCost());
    		post.setInt(9, station.getNumStation());
    		post.setInt(10, station.getStationAvailability());
    		post.setString(11, station.getStationSchedule());
    		post.setString(12, station.getNavigateLink());
    		post.setString(13, station.getStationCity());
    		
			rowCount = post.executeUpdate();
    		
    		
    	} catch(Exception e) {
    		e.printStackTrace();
    	}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}	
    }
    
    public void updateStation(ChargingStation station){
		conn = DBConnection.getConnection();
		PreparedStatement post;
		try {
			post = conn.prepareStatement("update station set stationName = ?, stationAddress = ?, lat = ?, lng = ?, stationStatus = ?, stationOutput = ?, stationCost = ?, numStations = ?, stationAvailability = ?, stationSchedule = ?, stationCity = ?, navigateLink = ? where stationId = ?;");
    		post.setString(1, station.getStationName());
    		post.setString(2, station.getStationAddress());
    		post.setFloat(3, station.getLat());
    		post.setFloat(4, station.getLng());
    		post.setString(5,station.getStationStatus());
    		post.setString(6, station.getStationOutput());
    		post.setString(7, station.getStationCost());
    		post.setInt(8, station.getNumStation());
    		post.setInt(9, station.getStationAvailability());
    		post.setString(10, station.getStationSchedule());
    		post.setString(11, station.getNavigateLink());
    		post.setString(12, station.getStationCity());
    		post.setString(13, station.getStationId().toString());
			
			rowCount = post.executeUpdate();
			
			post2 = conn.prepareStatement("select * from station where stationId = ?");
			post2.setObject(1, station.getStationId().toString());
			rs= post2.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

	public int getRowCount() {
		return rowCount;
	}

	public ResultSet getRS() {
		return rs;
	}
    
	public Connection getConn() {
		return conn;
	}
	
}
