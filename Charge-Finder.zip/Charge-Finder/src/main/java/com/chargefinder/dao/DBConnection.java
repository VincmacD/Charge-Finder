package com.chargefinder.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // Database Schema
    // CREATE DATABASE loggy DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
    // CREATE TABLE logs (uuid CHAR(40) NOT NULL PRIMARY KEY, title CHAR(128),
    // content TEXT, createTimestamp Date);

    private static final String dbUser = "root";
    private static final String dbPassword = "root";
    private static final String dbConnection = "jdbc:mysql://localhost:3306/ChargeFinder?useSSL=false";
    
    public static Connection getConnection() {
        Connection connection = null;
        
        //attempts to retrieve JDBC driver and connect to database
        try {
            Class.forName("com.mysql.jdbc.Driver");			//gets the driver class
            connection = DriverManager.getConnection( dbConnection, dbUser, dbPassword);	//uses the DriverManager
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        catch (SQLException e) {	//if connection fails
            e.printStackTrace();
        }
        
        if (connection != null) {		//if connection succeeds
            System.out.println("Connected to database!");
        }

        return connection;
    }

}
