package com.chargefinder.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String dbUser = "root";
    private static final String dbPassword = "sql";
    private static final String dbConnection = "jdbc:mysql://localhost:3306/ChargeFinder?useSSL=false";
    
    public static Connection getConnection() {
        Connection connection = null;
        
        //attempts to retrieve JDBC driver and connect to database
        try {
            Class.forName("com.mysql.jdbc.Driver");			//gets the driver class
            connection = DriverManager.getConnection( dbConnection, dbUser, dbPassword);	//uses the DriverManager
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        catch (SQLException e) {	//if connection fails
            e.printStackTrace();
        }
        
        if (connection != null) {		//if connection succeeds
            System.out.println("Connected to database!");
        }

        return connection;
    }

}
