package com.chargefinder.bean;

import java.util.UUID;

public class ChargingStation {
private UUID stationId;
private String stationName;
private String stationAddress;
private float lat;
private float lng;
private String stationStatus;
private String stationOutput;
private String stationCost;
private int numStations;
private int stationAvailability;
private String stationSchedule;
private String navigateLink;
private String stationCity;

public ChargingStation() {
}

private ChargingStation(StationBuilder builder) {
	this.stationId = builder.stationId;
	this.stationName = builder.stationName;
	this.stationAddress = builder.stationAddress;
	this.lat = builder.lat;
	this.lng = builder.lng;
	this.stationStatus = builder.stationStatus;
	this.stationOutput = builder.stationOutput;
	this.stationCost = builder.stationCost;
	this.numStations = builder.numStations;
	this.stationAvailability = builder.stationAvailability;
	this.stationSchedule = builder.stationSchedule;
	this.navigateLink = builder.navigateLink;
	this.stationCity = builder.stationCity;
}

public UUID getStationId() {
	return stationId;
}
public String getStationName() {
	return stationName;
}
public String getStationAddress() {
	return stationAddress;
}
public float getLat() {
	return lat;
}
public float getLng() {
	return lng;
}
public String getStationStatus() {
	return stationStatus;
}
public String getStationOutput() {
	return stationOutput;
}
public String getStationCost() {
	return stationCost;
}
public int getNumStation() {
	return numStations;
}
public int getStationAvailability() {
	return stationAvailability;
}
public String getStationSchedule() {
	return stationSchedule;
}
public String getNavigateLink() {
	return navigateLink;
}
public String getStationCity() {
	return stationCity;
}

public static class StationBuilder{
	private UUID stationId;
	private String stationName;
	private String stationAddress;
	private float lat;
	private float lng;
	private String stationStatus;
	private String stationOutput;
	private String stationCost;
	private int numStations;
	private int stationAvailability;
	private String stationSchedule;
	private String navigateLink;
	private String stationCity;

public StationBuilder(String stationName) {
	this.stationId = UUID.randomUUID();
	this.stationName = stationName;
}
public StationBuilder stationAddress(String stationAddress) {
	this.stationAddress = stationAddress;
	return this;
}

public StationBuilder stationId(UUID stationId) {
	this.stationId = stationId;
	return this;
}

public StationBuilder lat(float lat) {
	this.lat = lat;
	return this;
}
public StationBuilder lng(float lng) {
	this.lng = lng;
	return this;
}
public StationBuilder stationStatus(String stationStatus) {
	this.stationStatus = stationStatus;
	return this;
}

public StationBuilder stationOutput(String stationOutput) {
	this.stationOutput = stationOutput;
	return this;
}
public StationBuilder stationCost(String stationCost) {
	this.stationCost = stationCost;
	return this;
}
public StationBuilder numStations(int numStations) {
	this.numStations = numStations;
	return this;
}
public StationBuilder stationAvailability(int stationAvailability) {
	this.stationAvailability = stationAvailability;
	return this;
}
public StationBuilder stationSchedule(String stationSchedule) {
	this.stationSchedule = stationSchedule;
	return this;
}
public StationBuilder navigateLink(String navigateLink) {
	this.navigateLink = navigateLink;
	return this;
}
public StationBuilder stationCity(String stationCity) {
	this.stationCity = stationCity;
	return this;
}
public ChargingStation build() {
	ChargingStation station = new ChargingStation(this);
	return station;
}
}
}
