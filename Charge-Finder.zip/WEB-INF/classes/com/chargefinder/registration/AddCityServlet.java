package com.chargefinder.registration;

import com.chargefinder.dao.ApplicationDao;
import com.chargefinder.bean.City;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CityServlet
 */
@WebServlet("/AddCity")
public class AddCityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cityName = request.getParameter("cityName");
		double cityLatitude = Double.parseDouble(request.getParameter("cityLatitude").toString());
		double cityLongitude = Double.parseDouble(request.getParameter("cityLongitude").toString());
		City city = new City(cityName, cityLatitude, cityLongitude);
		ApplicationDao dao = new ApplicationDao();
		dao.addCity(city);
		if (dao.getRowCount() > 0) {
			request.setAttribute("cityStatus", "success");
		}else {
			request.setAttribute("cityStatus", "failed");
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("add.jsp");
		dispatcher.forward(request, response);
		
	}
}