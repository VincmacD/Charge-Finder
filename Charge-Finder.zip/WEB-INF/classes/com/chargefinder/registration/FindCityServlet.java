package com.chargefinder.registration;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chargefinder.dao.ApplicationDao;

/**
 * Servlet implementation class FindCityServlet
 */
@WebServlet("/FindCity")
public class FindCityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
		String cityName = request.getParameter("changeCity").toString().toLowerCase();
		if( (cityName != null) && (cityName != "")){
			ApplicationDao dao = new ApplicationDao();
			dao.useCity(cityName);
			try {	
				if (dao.getRS().next()) {
					request.setAttribute("usecity", cityName);
					request.setAttribute("cityLat", dao.getRS().getFloat("lat"));
					request.setAttribute("cityLng", dao.getRS().getFloat("lng"));				
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}finally {
				try {
					dao.getConn().close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		dispatcher.forward(request, response);
	}
}
