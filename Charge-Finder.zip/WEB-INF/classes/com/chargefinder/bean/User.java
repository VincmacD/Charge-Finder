package com.chargefinder.bean;

import java.util.UUID;

public class User {
private UUID userId;
private String username;
private String email;
private String password;
private String phoneNumber;
private String userType;
private String userIdString;

public User() {
}
private User(UserBuilder builder) {
	this.userId = builder.userId;
	this.username = builder.username;
	this.email = builder.email;
	this.password = builder.password;
	this.phoneNumber = builder.phoneNumber;
	this.userType = builder.userType;
	this.userIdString = builder.userIdString;
}

public UUID getUserId() {
	return userId;
}

public String getUserIdString() {
	return userIdString;
}

public String getUsername() {
	return username;
}

public String getEmail() {
	return email;
}

public String getPassword() {
	return password;
}

public String getPhoneNumber() {
	return phoneNumber;
}

public String getUserType() {
	return userType;
}

public static class UserBuilder{
	private UUID userId;
	private String username;
	private String email;
	private String password;
	private String phoneNumber;
	private String userType;
	private String userIdString;

public UserBuilder (String username) {
	this.userId = UUID.randomUUID();
	this.username = username;
}
public UserBuilder email(String email ) {
	this.email = email;
	return this;
}

public UserBuilder password(String password) {
	this.password = password;
	return this;
}

public UserBuilder phoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
	return this;
}

public UserBuilder userType(String userType) {
	this.userType = userType;
	return this;
}

public UserBuilder userIdString(String userIdString) {
	this.userIdString = userIdString;
	return this;
}

public UserBuilder userId(UUID userId) {
	this.userId = userId;
	return this;
}

public User build() {
	User user = new User(this);
	return user;
}

}
}
