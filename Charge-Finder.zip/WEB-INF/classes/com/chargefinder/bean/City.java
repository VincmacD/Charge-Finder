package com.chargefinder.bean;

public class City {
	private String cityName;
	private double cityLat;
	private double cityLng;
	
	public City(String cityName, double cityLatitude, double cityLongitude) {
		this.cityName = cityName;
		this.cityLat = cityLatitude;
		this.cityLng = cityLongitude;
	}

	public String getCityName() {
		return cityName;
	}

	public double getCityLat() {
		return cityLat;
	}

	public double getCityLng() {
		return cityLng;
	}
}
